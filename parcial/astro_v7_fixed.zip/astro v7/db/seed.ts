import { Role, User, db } from 'astro:db';
import { v4 as UUID } from 'uuid';
import bcrypt from 'bcryptjs';


// https://astro.build/db/seed
export default async function seed() {
 const roles = [
   { id: 'admin', name: 'Administrador' },
   { id: 'user', name: 'Usuario de sistema' },
   { id: 'super-user', name: 'Super usuario' },
 ];


 const jorge = {
   id: UUID(),
   name: 'jorge',
   direccion: 'pueba de direccion',
   telefono: '1234567890',
   email: 'jorgecoto.prof@uls.edu.sv',
   password: bcrypt.hashSync('123456'),
   role: 'admin',
 };


 const jorge2 = {
   id: UUID(),
   name: 'jorge coto',
   direccion: 'Sin especificar',
   telefono: '00000000',
   email: 'jorgealberto.cotozelaya@gmail.com',
   password: bcrypt.hashSync('123456'),
   role: 'admin',
 };

 /** Siempre rol admin tras cada seed. Login: email/contraseña (Firebase puede fallar → usa bcrypt en BD). */
 const adminPermanente = {
   id: UUID(),
   name: 'Administrador permanente',
   direccion: 'Sistema',
   telefono: '00000000',
   email: 'admin.permanente@astrostore.local',
   password: bcrypt.hashSync('AdminAstroStore2026!'),
   role: 'admin' as const,
 };


 await db.insert(Role).values(roles);
 await db.insert(User).values([jorge, jorge2, adminPermanente]);
}
