declare module "astro:actions" {
	type Actions = typeof import("C:/Users/xam_7/Downloads/astro-framework-auth-V5/astro-framework-auth-V5/src/actions")["server"];

	export const actions: Actions;
}