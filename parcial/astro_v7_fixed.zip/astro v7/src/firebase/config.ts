
// Import the functions you need from the SDKs you need
import { getApp, getApps, initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries


// nuevo
import { getAuth } from 'firebase/auth';
// fin nuevo

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyB4Nmr8CQTbc3Gl8qr7RhOBQv4zSSMGLrg",
  authDomain: "astro-authentication-2.firebaseapp.com",
  projectId: "astro-authentication-2",
  storageBucket: "astro-authentication-2.firebasestorage.app",
  messagingSenderId: "983052114108",
  appId: "1:983052114108:web:e95148bb34f6887354d8b9"
};

// Evita duplicate-app al recargar el módulo (HMR / varias importaciones)
const app =
  getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();



// esto se coloca
const auth = getAuth(app);
auth.languageCode = 'es';

export const firebase = {
  app,
  auth,
};