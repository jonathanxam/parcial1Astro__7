import type { AuthenticationResponse, User as ScalekitUser } from '@scalekit-sdk/node';
import type { AstroCookies } from 'astro';

const ACCESS = 'sk_access_token';
const REFRESH = 'sk_refresh_token';
const PROFILE = 'sk_profile';
const OAUTH_STATE = 'sk_oauth_state';

function cookieBase() {
  return {
    path: '/',
    httpOnly: true,
    secure: import.meta.env.PROD,
    sameSite: 'lax' as const,
  };
}

function scalekitUserToLocal(user: ScalekitUser) {
  const name =
    user.name ||
    user.username ||
    (user.email ? user.email.split('@')[0] : 'Usuario');
  return {
    avatar: user.picture ?? '',
    email: user.email,
    name,
    emailVerified: user.emailVerified,
  };
}

export function setScalekitSession(
  cookies: AstroCookies,
  auth: AuthenticationResponse
) {
  const access =
    typeof auth.accessToken === 'string' ? auth.accessToken.trim() : '';
  if (!access) {
    throw new Error(
      'Scalekit no devolvió access_token (revisa CLIENT_ID / CLIENT_SECRET y el entorno).'
    );
  }

  const base = cookieBase();
  const expSec = Number(auth.expiresIn);
  const maxAccess =
    Number.isFinite(expSec) && expSec > 0 ? Math.max(Math.floor(expSec), 60) : 3600;

  cookies.set(ACCESS, access, { ...base, maxAge: maxAccess });

  const refresh =
    typeof auth.refreshToken === 'string' ? auth.refreshToken.trim() : '';
  if (refresh) {
    cookies.set(REFRESH, refresh, {
      ...base,
      maxAge: 60 * 60 * 24 * 30,
    });
  }

  cookies.set(
    PROFILE,
    JSON.stringify(scalekitUserToLocal(auth.user)),
    { ...base, maxAge: 60 * 60 * 24 * 30 }
  );
}

export function getScalekitSession(cookies: AstroCookies) {
  const token = cookies.get(ACCESS)?.value;
  const profileRaw = cookies.get(PROFILE)?.value;
  if (!token || !profileRaw) return null;

  try {
    const parsed = JSON.parse(profileRaw) as {
      email: string;
      name: string;
      avatar: string;
      emailVerified: boolean;
    };
    if (!parsed?.email) return null;
    return parsed;
  } catch {
    return null;
  }
}

export function clearScalekitSession(cookies: AstroCookies) {
  const path = { path: '/' };
  cookies.delete(ACCESS, path);
  cookies.delete(REFRESH, path);
  cookies.delete(PROFILE, path);
  cookies.delete(OAUTH_STATE, path);
}

export function setOAuthStateCookie(cookies: AstroCookies, state: string) {
  cookies.set(OAUTH_STATE, state, {
    ...cookieBase(),
    maxAge: 600,
  });
}

export function getOAuthStateCookie(cookies: AstroCookies) {
  return cookies.get(OAUTH_STATE)?.value ?? null;
}
