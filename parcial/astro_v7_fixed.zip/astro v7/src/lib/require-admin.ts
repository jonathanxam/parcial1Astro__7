import type { AstroCookies } from 'astro';
import { findUserById } from '@/lib/user-repo';
import { getAppUserId } from '@/lib/app-session';

export async function assertAdminOrSuperUser(cookies: AstroCookies) {
  const uid = getAppUserId(cookies);
  if (!uid) {
    throw new Error('No autenticado');
  }

  const row = await findUserById(uid);
  const role = row?.role;
  if (role !== 'admin' && role !== 'super-user') {
    throw new Error('Se requiere rol administrador');
  }
}
