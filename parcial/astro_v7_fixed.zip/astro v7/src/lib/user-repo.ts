import { db, User, eq } from 'astro:db';
import { and, asc, inArray, like, or, sql } from 'drizzle-orm';
import type { SQL } from 'drizzle-orm';

export type DbUser = typeof User.$inferSelect;

/** Máximo de usuarios por página en el listado admin */
export const PAGE_SIZE = 5;

export async function findUserById(id: string) {
  const rows = await db.select().from(User).where(eq(User.id, id)).limit(1);
  return rows[0] ?? null;
}

export async function findUserByEmail(email: string) {
  const rows = await db.select().from(User).where(eq(User.email, email)).limit(1);
  return rows[0] ?? null;
}

export async function countUsers() {
  const rows = await db
    .select({ n: sql<number>`count(*)`.mapWith(Number) })
    .from(User);
  return rows[0]?.n ?? 0;
}

/** Administradores + super usuarios (tarjeta “Admins”) */
export async function countAdminUsers() {
  const rows = await db
    .select({ n: sql<number>`count(*)`.mapWith(Number) })
    .from(User)
    .where(inArray(User.role, ['admin', 'super-user']));
  return rows[0]?.n ?? 0;
}

function buildUserFilter(q: string, roleFilter: string): SQL | undefined {
  const parts: SQL[] = [];
  const trimmed = q.trim();
  if (trimmed) {
    const pat = `%${trimmed}%`;
    parts.push(or(like(User.name, pat), like(User.email, pat))!);
  }
  if (
    roleFilter === 'admin' ||
    roleFilter === 'user' ||
    roleFilter === 'super-user'
  ) {
    parts.push(eq(User.role, roleFilter));
  }
  if (parts.length === 0) return undefined;
  if (parts.length === 1) return parts[0];
  return and(parts[0], parts[1])!;
}

export async function countUsersFiltered(q: string, roleFilter: string) {
  const w = buildUserFilter(q, roleFilter);
  if (!w) return countUsers();
  const rows = await db
    .select({ n: sql<number>`count(*)`.mapWith(Number) })
    .from(User)
    .where(w);
  return rows[0]?.n ?? 0;
}

export async function listUsersPage(page: number, q = '', roleFilter = '') {
  const w = buildUserFilter(q, roleFilter);
  const total = await countUsersFiltered(q, roleFilter);
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const safePage = Math.min(Math.max(1, page), totalPages);
  const offset = (safePage - 1) * PAGE_SIZE;

  const rows = w
    ? await db
        .select()
        .from(User)
        .where(w)
        .orderBy(asc(User.createdAt))
        .limit(PAGE_SIZE)
        .offset(offset)
    : await db
        .select()
        .from(User)
        .orderBy(asc(User.createdAt))
        .limit(PAGE_SIZE)
        .offset(offset);

  const start = total === 0 ? 0 : offset + 1;
  const end = Math.min(offset + PAGE_SIZE, total);

  return {
    users: rows,
    total,
    totalPages,
    page: safePage,
    pageSize: PAGE_SIZE,
    rangeStart: start,
    rangeEnd: end,
  };
}
