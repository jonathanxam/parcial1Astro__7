/**
 * Origen público de la app para OAuth. Debe ser el mismo base que uses en
 * "Redirect URIs" en Scalekit (mismo host, esquema y puerto).
 */
export function getScalekitRedirectUri(requestUrl: URL): string {
  const fromEnv = import.meta.env.PUBLIC_APP_ORIGIN?.trim();
  const site = import.meta.env.SITE;

  const base =
    (fromEnv && fromEnv.replace(/\/$/, '')) ||
    (site && String(site).replace(/\/$/, '')) ||
    requestUrl.origin;

  return `${base}/auth/scalekit/callback`;
}
