import type { AstroCookies } from 'astro';

export const APP_USER_COOKIE = 'app_uid';

const baseOpts = () => ({
  path: '/',
  httpOnly: true,
  secure: import.meta.env.PROD,
  sameSite: 'lax' as const,
  maxAge: 60 * 60 * 24 * 30,
});

export function setAppUserCookie(cookies: AstroCookies, userId: string) {
  cookies.set(APP_USER_COOKIE, userId, baseOpts());
}

export function clearAppUserCookie(cookies: AstroCookies) {
  cookies.delete(APP_USER_COOKIE, { path: '/' });
}

export function getAppUserId(cookies: AstroCookies): string | undefined {
  return cookies.get(APP_USER_COOKIE)?.value;
}
