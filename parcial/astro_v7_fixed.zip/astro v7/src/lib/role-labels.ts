const LABELS: Record<string, string> = {
  admin: 'Administrador',
  user: 'Usuario',
  'super-user': 'Super usuario',
};

export function roleLabel(roleId: string): string {
  return LABELS[roleId] ?? roleId;
}
