import { ScalekitClient } from '@scalekit-sdk/node';

let client: ScalekitClient | null = null;

function readEnvTrim(key: string): string {
  const v = import.meta.env[key];
  return typeof v === 'string' ? v.trim() : '';
}

export function getScalekitClient(): ScalekitClient {
  const envUrl = readEnvTrim('SCALEKIT_ENV_URL');
  const clientId = readEnvTrim('SCALEKIT_CLIENT_ID');
  const clientSecret = readEnvTrim('SCALEKIT_CLIENT_SECRET');

  if (!envUrl || !clientId || !clientSecret) {
    throw new Error(
      'Configura SCALEKIT_ENV_URL, SCALEKIT_CLIENT_ID y SCALEKIT_CLIENT_SECRET (sin espacios ni comillas de más en .env)'
    );
  }

  if (!client) {
    client = new ScalekitClient(envUrl, clientId, clientSecret);
  }

  return client;
}

export function isScalekitConfigured(): boolean {
  return !!(
    readEnvTrim('SCALEKIT_ENV_URL') &&
    readEnvTrim('SCALEKIT_CLIENT_ID') &&
    readEnvTrim('SCALEKIT_CLIENT_SECRET')
  );
}
