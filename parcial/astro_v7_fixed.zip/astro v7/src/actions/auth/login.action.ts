// src/actions/auth/login.action.ts
import { setAppUserCookie } from '@/lib/app-session';
import { findUserByEmail, findUserById } from '@/lib/user-repo';
import { firebase } from '@/firebase/config';
import { defineAction } from 'astro:actions';
import { z } from 'astro:schema';
import { signInWithEmailAndPassword, type AuthError } from 'firebase/auth';
import bcrypt from 'bcryptjs';
import { db, User } from 'astro:db';

export const loginUser = defineAction({
  accept: 'form',
  input: z.object({
    email: z.string().email(),
    password: z.string().min(6),
    remember_me: z.boolean().optional(),
  }),
  handler: async ({ email, password, remember_me }, { cookies }) => {
    // Cookies
    if (remember_me) {
      cookies.set('email', email, {
        expires: new Date(Date.now() + 1000 * 60 * 60 * 24 * 365),
        path: '/',
      });
    } else {
      cookies.delete('email', { path: '/' });
    }

    try {
      const userCredential = await signInWithEmailAndPassword(
        firebase.auth,
        email,
        password
      );

      const uid = userCredential.user.uid;
      let row = await findUserById(uid);
      if (!row) {
        await db.insert(User).values({
          id: uid,
          name: userCredential.user.displayName ?? email.split('@')[0],
          email,
          telefono: '',
          direccion: '',
          password: bcrypt.hashSync(password),
          role: 'user',
          createdAt: new Date(),
        });
      }
      setAppUserCookie(cookies, uid);

      const rowSession = await findUserById(uid);

      return {
        success: true,
        role: rowSession?.role ?? 'user',
        user: {
          uid: userCredential.user.uid,
          email: userCredential.user.email,
          displayName: userCredential.user.displayName,
          emailVerified: userCredential.user.emailVerified,
        },
      };
      
    } catch (error) {
      const row = await findUserByEmail(email);
      if (row && bcrypt.compareSync(password, row.password)) {
        setAppUserCookie(cookies, row.id);
        const sessionRow = await findUserById(row.id);
        return {
          success: true,
          role: sessionRow?.role ?? 'user',
          user: {
            uid: row.id,
            email: row.email,
            displayName: row.name,
            emailVerified: false,
          },
        };
      }

      const firebaseError = error as AuthError;

      if (firebaseError.code === 'auth/invalid-credential') {
        throw new Error('Email o contraseña incorrectos');
      }

      if (firebaseError.code === 'auth/user-not-found') {
        throw new Error('No existe una cuenta con este email');
      }

      if (firebaseError.code === 'auth/wrong-password') {
        throw new Error('Contraseña incorrecta');
      }

      console.error('Error de login:', firebaseError);
      throw new Error('Error al iniciar sesión');
    }
  },
});