import { setAppUserCookie } from '@/lib/app-session';
import { findUserByEmail } from '@/lib/user-repo';
import { firebase } from '@/firebase/config';
import { defineAction } from 'astro:actions';
import { z } from 'astro:schema';

import { GoogleAuthProvider, signInWithCredential } from 'firebase/auth';
import bcrypt from 'bcryptjs';
import { v4 as uuid } from 'uuid';
import { db, User } from 'astro:db';

/** Payload serializable: `UserCredential` completo no se puede enviar por JSON a la acción. */
export const loginWithGoogle = defineAction({
  accept: 'json',
  input: z.object({
    idToken: z.string().min(1),
    accessToken: z.string().optional(),
  }),
  handler: async ({ idToken, accessToken }, { cookies }) => {
    const credential = GoogleAuthProvider.credential(
      idToken,
      accessToken ?? null
    );

    const userCredential = await signInWithCredential(
      firebase.auth,
      credential
    );
    const u = userCredential.user;
    const uid = u.uid;
    const email = u.email ?? '';
    if (!email) {
      throw new Error('Google no devolvió email');
    }

    const existing = await findUserByEmail(email);
    if (!existing) {
      await db.insert(User).values({
        id: uid,
        name: u.displayName ?? email.split('@')[0],
        email,
        telefono: '',
        direccion: '',
        password: bcrypt.hashSync(`oauth:${uuid()}`),
        role: 'user',
        createdAt: new Date(),
      });
    }

    setAppUserCookie(cookies, uid);

    const row = await findUserByEmail(email);
    return { ok: true as const, role: row?.role ?? 'user' };
  },
});

