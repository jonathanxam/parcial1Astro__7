import { defineAction,   } from 'astro:actions';
import { z } from 'astro:schema';

import {
  createUserWithEmailAndPassword,
  sendEmailVerification,
  updateProfile,
  type AuthError,
} from 'firebase/auth';
import { firebase } from '@/firebase/config';
import bcrypt from 'bcryptjs';
import { db, User } from 'astro:db';

export const registerUser = defineAction({
  accept: 'form',
  input: z.object({
    name: z.string().min(2),
    email: z.string().email(),
    password: z.string().min(6),
    remember_me: z.boolean().optional(),
  }),
  handler: async ({ name, email, password, remember_me }, { cookies }) => {
    // Cookies
    if (remember_me) {
      cookies.set('name', name, {
        expires: new Date(Date.now() + 1000 * 60 * 60 * 24 * 365),
        path: '/',
      });

      cookies.set('email', email, {
        expires: new Date(Date.now() + 1000 * 60 * 60 * 24 * 365),
        path: '/',
      });
    } else {
      cookies.delete('email', { path: '/' });
      cookies.delete('name', { path: '/' });
    }

    // Creación de usuario con Firebase
    try {
      const userCredential = await createUserWithEmailAndPassword(
        firebase.auth,
        email,
        password
      );

      // Actualizar el nombre del usuario
      await updateProfile(userCredential.user, {
        displayName: name,
      });

      // Enviar verificación de email
      await sendEmailVerification(userCredential.user, {
        url: 'http://localhost:4321/protected?emailVerified=true',
      });

      await db.insert(User).values({
        id: userCredential.user.uid,
        name,
        email,
        telefono: '',
        direccion: '',
        password: bcrypt.hashSync(password),
        role: 'user',
        createdAt: new Date(),
      });

      // ✅ Retornar un objeto con el usuario y un mensaje de éxito
      return {
        success: true,
        message: `¡Bienvenido ${name}! Tu cuenta ha sido creada exitosamente.`,
        user: {
          uid: userCredential.user.uid,
          email: userCredential.user.email,
          displayName: userCredential.user.displayName,
        }
      };
      
    } catch (error) {
      const firebaseError = error as AuthError;
      console.log(firebaseError);
      
      if (firebaseError.code === 'auth/email-already-in-use') {
        throw new Error('El correo ya está en uso');
      }
      
      if (firebaseError.code === 'auth/weak-password') {
        throw new Error('La contraseña es muy débil. Usa al menos 6 caracteres');
      }

      throw new Error('Ocurrió un error al crear tu cuenta. Intenta nuevamente');
    }

        // return { ok:true, msg: "Usuario creado" }  
    // return true;

    
  },
});