import { clearAppUserCookie } from '@/lib/app-session';
import { firebase } from '@/firebase/config';
import { clearScalekitSession } from '@/lib/scalekit-session';
import { defineAction,  } from 'astro:actions';
import { signOut } from 'firebase/auth';

export const logout = defineAction({
  accept: 'json',
  handler: async (_, { cookies }) => {
    clearAppUserCookie(cookies);
    clearScalekitSession(cookies);
    await signOut(firebase.auth);
  },
});
