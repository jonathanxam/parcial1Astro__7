import {
  adminCreateUser,
  adminDeleteUser,
  adminUpdateUser,
} from './admin/users.actions';
import { loginUser, loginWithGoogle, logout, registerUser } from './auth';

export const server = {
  registerUser,
  logout,
  loginUser,
  loginWithGoogle,
  adminCreateUser,
  adminUpdateUser,
  adminDeleteUser,
};
