import { firebase } from '@/firebase/config';
import { assertAdminOrSuperUser } from '@/lib/require-admin';
import { getAppUserId } from '@/lib/app-session';
import { PAGE_SIZE, countUsers, findUserByEmail } from '@/lib/user-repo';
import { defineAction } from 'astro:actions';
import { z } from 'astro:schema';
import {
  createUserWithEmailAndPassword,
  updateProfile,
} from 'firebase/auth';
import bcrypt from 'bcryptjs';
import { v4 as uuid } from 'uuid';
import { db, User, eq } from 'astro:db';

const roleEnum = z.enum(['admin', 'user', 'super-user']);

const requiredContact = z
  .string()
  .trim()
  .min(1, 'Este campo es obligatorio');

export const adminCreateUser = defineAction({
  accept: 'json',
  input: z.object({
    name: z.string().min(2),
    email: z.string().email(),
    password: z.string().min(6),
    telefono: requiredContact,
    direccion: requiredContact,
    role: roleEnum,
  }),
  handler: async ({ name, email, password, telefono, direccion, role }, { cookies }) => {
    await assertAdminOrSuperUser(cookies);

    const dup = await findUserByEmail(email);
    if (dup) {
      throw new Error('El email ya está registrado en la aplicación');
    }

    let userId: string;

    try {
      const cred = await createUserWithEmailAndPassword(
        firebase.auth,
        email,
        password
      );
      await updateProfile(cred.user, { displayName: name });
      userId = cred.user.uid;
    } catch (e: unknown) {
      const code =
        e && typeof e === 'object' && 'code' in e
          ? String((e as { code: string }).code)
          : '';
      if (code === 'auth/email-already-in-use') {
        throw new Error(
          'Este email ya existe en Firebase. Usa otro correo o sincroniza la cuenta.'
        );
      }
      console.warn(
        '[adminCreateUser] Firebase no creó el usuario (servidor/red). Se guarda solo en BD local:',
        e
      );
      userId = uuid();
    }

    await db.insert(User).values({
      id: userId,
      name,
      email,
      telefono: telefono.trim(),
      direccion: direccion.trim(),
      password: bcrypt.hashSync(password),
      role,
      createdAt: new Date(),
    });

    const total = await countUsers();
    const lastPage = Math.max(1, Math.ceil(total / PAGE_SIZE));

    return { ok: true as const, lastPage };
  },
});

export const adminUpdateUser = defineAction({
  accept: 'json',
  input: z.object({
    id: z.string(),
    name: z.string().min(2),
    email: z.string().email(),
    telefono: requiredContact,
    direccion: requiredContact,
    role: roleEnum,
  }),
  handler: async ({ id, name, email, telefono, direccion, role }, { cookies }) => {
    await assertAdminOrSuperUser(cookies);

    await db
      .update(User)
      .set({
        name,
        email,
        telefono: telefono.trim(),
        direccion: direccion.trim(),
        role,
      })
      .where(eq(User.id, id));

    return { ok: true as const };
  },
});

export const adminDeleteUser = defineAction({
  accept: 'json',
  input: z.object({
    id: z.string(),
  }),
  handler: async ({ id }, { cookies }) => {
    await assertAdminOrSuperUser(cookies);

    const selfId = getAppUserId(cookies);
    if (id === selfId) {
      throw new Error('No puedes eliminar tu propio usuario');
    }

    await db.delete(User).where(eq(User.id, id));

    return { ok: true as const };
  },
});
