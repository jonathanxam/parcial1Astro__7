import type { APIRoute } from 'astro';
import type { AuthenticationResponse } from '@scalekit-sdk/node';
import { setAppUserCookie } from '@/lib/app-session';
import { getScalekitClient } from '@/lib/scalekit-client';
import { getScalekitRedirectUri } from '@/lib/scalekit-redirect';
import { findUserByEmail, findUserById } from '@/lib/user-repo';
import { getOAuthStateCookie, setScalekitSession } from '@/lib/scalekit-session';
import bcrypt from 'bcryptjs';
import { decodeJwt } from 'jose';
import { v4 as uuid } from 'uuid';
import { db, User } from 'astro:db';

function emailFromAuth(
  userEmail: string | undefined,
  idToken: string | undefined
): string | undefined {
  const u = userEmail?.trim();
  if (u) return u;
  if (!idToken) return undefined;
  try {
    const c = decodeJwt(idToken) as {
      email?: string;
      preferred_username?: string;
    };
    const e = c.email ?? c.preferred_username;
    return typeof e === 'string' ? e.trim() : undefined;
  } catch {
    return undefined;
  }
}

export const GET: APIRoute = async ({ url, cookies, redirect }) => {
  const params = url.searchParams;
  const err = params.get('error');
  if (err) {
    const desc = params.get('error_description') ?? err;
    return redirect(`/login?error=${encodeURIComponent(desc)}`);
  }

  const client = getScalekitClient();
  const redirectUri = getScalekitRedirectUri(url);

  const idpInitiated = params.get('idp_initiated_login');
  if (idpInitiated) {
    try {
      const claims = await client.getIdpInitiatedLoginClaims(idpInitiated);
      const authUrl = client.getAuthorizationUrl(redirectUri, {
        connectionId: claims.connection_id,
        organizationId: claims.organization_id,
        loginHint: claims.login_hint,
        ...(claims.relay_state && { state: claims.relay_state }),
      });
      return redirect(authUrl);
    } catch {
      return redirect('/login?error=idp_initiated_failed');
    }
  }

  const code = params.get('code');
  const state = params.get('state');
  const savedState = getOAuthStateCookie(cookies);
  cookies.delete('sk_oauth_state', { path: '/' });

  if (!code || !state || !savedState || state !== savedState) {
    return redirect('/login?error=oauth_state_invalid');
  }

  try {
    const authResp = await client.authenticateWithCode(code, redirectUri);

    const email = emailFromAuth(authResp.user.email, authResp.idToken);
    if (!email) {
      return redirect(
        `/login?error=${encodeURIComponent(
          'Scalekit no devolvió email. En el dashboard revisa scopes openid, profile y email.'
        )}`
      );
    }

    const sessionPayload: AuthenticationResponse = {
      ...authResp,
      user: {
        ...authResp.user,
        email,
        name: authResp.user.name || email.split('@')[0],
      },
    };
    setScalekitSession(cookies, sessionPayload);

    let row = await findUserByEmail(email);
    if (!row) {
      const id = uuid();
      await db.insert(User).values({
        id,
        name: authResp.user.name ?? email.split('@')[0],
        email,
        telefono: '',
        direccion: '',
        password: bcrypt.hashSync(`scalekit:${uuid()}`),
        role: 'user',
        createdAt: new Date(),
      });
      row = await findUserById(id);
    }
    if (row) {
      setAppUserCookie(cookies, row.id);
    }

    const toAdmin =
      row?.role === 'admin' || row?.role === 'super-user';
    return redirect(toAdmin ? '/admin/users' : '/protected');
  } catch (e) {
    const msg =
      e instanceof Error
        ? e.message
        : typeof e === 'object' && e !== null && 'message' in e
          ? String((e as { message: unknown }).message)
          : String(e);
    console.error('[scalekit/callback] authenticateWithCode:', msg, e);
    const safe = msg.slice(0, 400);
    return redirect(
      `/login?error=${encodeURIComponent(`Scalekit: ${safe}`)}`
    );
  }
};
