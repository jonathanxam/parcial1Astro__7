import type { APIRoute } from 'astro';
import { randomBytes } from 'node:crypto';
import { getScalekitClient, isScalekitConfigured } from '@/lib/scalekit-client';
import { getScalekitRedirectUri } from '@/lib/scalekit-redirect';
import { setOAuthStateCookie } from '@/lib/scalekit-session';

const NEED_ENV_MSG =
  'Scalekit: crea o edita el archivo .env en la raíz del proyecto con SCALEKIT_ENV_URL, SCALEKIT_CLIENT_ID y SCALEKIT_CLIENT_SECRET (dashboard Scalekit → Developers). Reinicia astro dev después de guardar.';

export const GET: APIRoute = async ({ redirect, url, cookies }) => {
  if (!isScalekitConfigured()) {
    return redirect(`/login?error=${encodeURIComponent(NEED_ENV_MSG)}`);
  }

  const client = getScalekitClient();
  const redirectUri = getScalekitRedirectUri(url);
  const state = randomBytes(24).toString('hex');
  setOAuthStateCookie(cookies, state);

  const connectionId = import.meta.env.SCALEKIT_CONNECTION_ID;
  const organizationId = import.meta.env.SCALEKIT_ORGANIZATION_ID;
  const provider = import.meta.env.SCALEKIT_PROVIDER;

  const authUrl = client.getAuthorizationUrl(redirectUri, {
    state,
    ...(connectionId && { connectionId }),
    ...(organizationId && { organizationId }),
    ...(provider && { provider }),
  });

  return redirect(authUrl);
};
