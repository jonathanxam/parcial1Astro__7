import type { APIRoute } from 'astro';

/** Evita 404 en `/auth/scalekit`; el flujo OAuth usa `/auth/scalekit/login`. */
export const GET: APIRoute = ({ redirect }) =>
  redirect('/auth/scalekit/login');
