import type { APIRoute } from 'astro';
import { isScalekitConfigured } from '@/lib/scalekit-client';
import { getScalekitRedirectUri } from '@/lib/scalekit-redirect';

/**
 * Solo desarrollo: muestra el redirect_uri efectivo para comparar con el dashboard.
 */
export const GET: APIRoute = ({ url }) => {
  if (!import.meta.env.DEV) {
    return new Response('Not found', { status: 404 });
  }

  const redirectUri = getScalekitRedirectUri(url);

  const body = {
    redirectUriParaAllowedCallbackUrls: redirectUri,
    requestOrigin: url.origin,
    PUBLIC_APP_ORIGIN: import.meta.env.PUBLIC_APP_ORIGIN ?? null,
    SITE: import.meta.env.SITE ?? null,
    scalekitEnvOk: isScalekitConfigured(),
    nota:
      'En Scalekit: Dashboard → Authentication → Redirect URLs → Allowed callback URLs',
  };

  return new Response(JSON.stringify(body, null, 2), {
    headers: { 'Content-Type': 'application/json; charset=utf-8' },
  });
};
