import { defineMiddleware } from 'astro:middleware';
import { getAppUserId, setAppUserCookie } from './lib/app-session';
import { getScalekitSession } from './lib/scalekit-session';
import { findUserByEmail, findUserById } from './lib/user-repo';

const privateRoutes = ['/protected'];
const notAuthenticatedRoutes = ['/login', '/register'];

function mapDbUser(
  row: { email: string; name: string; role: string },
  avatar = ''
): User {
  return {
    email: row.email,
    name: row.name,
    avatar,
    emailVerified: true,
    role: row.role,
  };
}

export const onRequest = defineMiddleware(
  async ({ url, locals, redirect, cookies }, next) => {
    const uid = getAppUserId(cookies);
    let resolved: User | null = null;

    if (uid) {
      const row = await findUserById(uid);
      if (row) {
        resolved = mapDbUser(row);
      }
    }

    if (!resolved) {
      const sk = getScalekitSession(cookies);
      if (sk?.email) {
        const row = await findUserByEmail(sk.email);
        if (row) {
          resolved = mapDbUser(row, sk.avatar);
          setAppUserCookie(cookies, row.id);
        } else {
          resolved = {
            email: sk.email,
            name: sk.name,
            avatar: sk.avatar,
            emailVerified: sk.emailVerified,
            role: 'user',
          };
        }
      }
    }

    locals.isLoggedIn = !!resolved;
    locals.user = resolved;

    if (url.pathname === '/' && !locals.isLoggedIn) {
      return redirect('/login');
    }

    if (url.pathname.startsWith('/admin')) {
      const r = locals.user?.role;
      if (!locals.isLoggedIn || (r !== 'admin' && r !== 'super-user')) {
        return redirect('/');
      }
    }

    if (!locals.isLoggedIn && privateRoutes.includes(url.pathname)) {
      return redirect('/');
    }

    if (locals.isLoggedIn && notAuthenticatedRoutes.includes(url.pathname)) {
      return redirect('/');
    }

    return next();
  }
);
