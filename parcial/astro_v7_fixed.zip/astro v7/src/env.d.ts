/// <reference path="../.astro/db-types.d.ts" />
/// <reference path="../.astro/types.d.ts" />
/// <reference path="../.astro/actions.d.ts" />
/// <reference types="astro/client" />

interface User {
  email: string;
  name: string;
  avatar: string;
  emailVerified: boolean;
  role: string;
}

declare namespace App {
  interface Locals {
    isLoggedIn: boolean;
    user: User | null;
  }
}

interface ImportMetaEnv {
  readonly SCALEKIT_ENV_URL?: string;
  readonly SCALEKIT_CLIENT_ID?: string;
  readonly SCALEKIT_CLIENT_SECRET?: string;
  /** SSO: ID de conexión en Scalekit (opcional) */
  readonly SCALEKIT_CONNECTION_ID?: string;
  /** SSO: organización (opcional) */
  readonly SCALEKIT_ORGANIZATION_ID?: string;
  /** Login social, p. ej. `google` (opcional) */
  readonly SCALEKIT_PROVIDER?: string;
  /**
   * Origen público (sin barra final). Debe coincidir con la Redirect URI registrada en Scalekit.
   * Ej: http://localhost:4321 — la callback será {PUBLIC_APP_ORIGIN}/auth/scalekit/callback
   */
  readonly PUBLIC_APP_ORIGIN?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
